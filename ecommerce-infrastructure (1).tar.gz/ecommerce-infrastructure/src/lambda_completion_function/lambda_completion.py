import boto3
from PIL import Image
from io import BytesIO
import os
from urllib.parse import unquote_plus
import openai
import pandas as pd
import json

s3 = boto3.client('s3')
rekognition = boto3.client('rekognition')
openai.api_key = os.getenv('OPENAI_API_KEY')

def get_image_metadata(image_bytes):
    response = rekognition.detect_labels(
        Image={'Bytes': image_bytes},
        MaxLabels=10,
        MinConfidence=80
    )
    return response['Labels']

def generate_listing_details(keywords):
    prompt = f"""Create a professional and engaging product listing for an eBay item with the following details:
    Keywords: {keywords}
    Include the following sections:
    1. Product Description
    2. Item Specifics
    3. Shipping Details
    4. Payment Policy
    5. Return Policy"""
    
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=prompt,
        max_tokens=500
    )
    return response.choices[0].text.strip()

def process_image_file(bucket_name, object_key, product_id_str, complete_bucket):
    response = s3.get_object(Bucket=bucket_name, Key=object_key)
    image_bytes = response['Body'].read()
    
    labels = get_image_metadata(image_bytes)
    keywords = ", ".join([label['Name'] for label in labels])
    
    listing_details = generate_listing_details(keywords)
    
    metadata_key = f"{product_id_str}/metadata/{os.path.basename(object_key)}.txt"
    s3.put_object(
        Bucket=complete_bucket,
        Key=metadata_key,
        Body=listing_details.encode('utf-8')
    )
    
    return {
        "product_id": product_id_str,
        "keywords": keywords,
        "listing_details": listing_details,
        "file_key": object_key
    }

def create_csv_file(product_details, file_path):
    df = pd.DataFrame(product_details)
    df.to_csv(file_path, index=False)

def lambda_handler(event, context):
    complete_bucket = event['Records'][0]['s3']['bucket']['name']
    object_key = unquote_plus(event['Records'][0]['s3']['object']['key'])
    
    eternal_elegance_bucket = 'eternal-elegance-complete'
    scent_blender_bucket = 'scent-blender-complete'
    
    try:
        product_id_str = object_key.split('/')[0]
        product_details = []
        
        if object_key.endswith('/'):
            response = s3.list_objects_v2(Bucket=complete_bucket, Prefix=object_key)
            if 'Contents' in response:
                for obj in response['Contents']:
                    if obj['Key'].endswith('/') or obj['Key'].endswith('.txt'):
                        continue
                    detail = process_image_file(complete_bucket, obj['Key'], product_id_str, complete_bucket)
                    if detail:
                        product_details.append(detail)
        else:
            if not object_key.endswith('.txt'):
                detail = process_image_file(complete_bucket, object_key, product_id_str, complete_bucket)
                if detail:
                    product_details.append(detail)
        
        if product_details:
            csv_file_path = "/tmp/product_details.csv"
            create_csv_file(product_details, csv_file_path)
            
            if 'jewelry' in object_key.lower():
                upload_bucket = eternal_elegance_bucket
            else:
                upload_bucket = scent_blender_bucket
            
            received_folder = f"{upload_bucket}/received"
            s3.upload_file(csv_file_path, received_folder, f"{product_id_str}/product_details.csv")
        
        return {
            'statusCode': 200,
            'body': 'Files processed and product details generated successfully.'
        }
    except Exception as e:
        print(e)
        return {
            'statusCode': 500,
            'body': f'Error occurred: {e}'
        }
