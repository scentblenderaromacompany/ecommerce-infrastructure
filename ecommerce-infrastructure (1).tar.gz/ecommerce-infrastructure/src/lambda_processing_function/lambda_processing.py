import boto3
from PIL import Image, ImageEnhance
from io import BytesIO
import os
import mimetypes
from urllib.parse import unquote_plus

s3 = boto3.client('s3')

def resize_and_enhance_image(image_bytes):
    with Image.open(BytesIO(image_bytes)) as img:
        img = img.convert("RGB")
        
        # Resize image
        img.thumbnail((800, 800), Image.ANTIALIAS)
        
        # Enhance image
        enhancer = ImageEnhance.Contrast(img)
        img = enhancer.enhance(1.2)
        
        enhancer = ImageEnhance.Sharpness(img)
        img = enhancer.enhance(1.2)
        
        enhancer = ImageEnhance.Color(img)
        img = enhancer.enhance(1.2)
        
        # Save image to buffer
        buffer = BytesIO()
        img.save(buffer, 'JPEG')
        buffer.seek(0)
        
        return buffer

def process_video(video_bytes):
    # Placeholder for video processing logic
    buffer = BytesIO(video_bytes)
    return buffer

def process_files(bucket_name, object_key, destination_bucket, product_id_str):
    try:
        file_extension = os.path.splitext(object_key)[1].lower()
        mime_type, _ = mimetypes.guess_type(object_key)
        file_type = mime_type or 'application/octet-stream'
        
        response = s3.get_object(Bucket=bucket_name, Key=object_key)
        file_bytes = response['Body'].read()
        
        if 'image' in file_type:
            processed_file = resize_and_enhance_image(file_bytes)
            new_object_key = f'{product_id_str}/images/{os.path.basename(object_key)}'
        elif 'video' in file_type:
            processed_file = process_video(file_bytes)
            new_object_key = f'{product_id_str}/videos/{os.path.basename(object_key)}'
        else:
            # Ignore metadata files and keep them as is
            return None
        
        # Upload processed file to the destination bucket
        s3.upload_fileobj(processed_file, destination_bucket, new_object_key)
        return new_object_key
    except Exception as e:
        print(e)
        return None

def lambda_handler(event, context):
    processing_bucket = event['Records'][0]['s3']['bucket']['name']
    object_key = unquote_plus(event['Records'][0]['s3']['object']['key'])
    complete_bucket = 'complete-bucket'
    
    try:
        product_id_str = object_key.split('/')[0]
        
        if object_key.endswith('/'):
            response = s3.list_objects_v2(Bucket=processing_bucket, Prefix=object_key)
            if 'Contents' in response:
                for obj in response['Contents']:
                    process_files(processing_bucket, obj['Key'], complete_bucket, product_id_str)
        else:
            process_files(processing_bucket, object_key, complete_bucket, product_id_str)
        
        return {
            'statusCode': 200,
            'body': f'Files processed and copied to {complete_bucket}/{product_id_str}'
        }
    except Exception as e:
        print(e)
        return {
            'statusCode': 500,
            'body': f'Error occurred: {e}'
        }
