import boto3
import json
import os
import requests
from urllib.parse import unquote_plus
import mimetypes

s3 = boto3.client('s3')
dynamodb = boto3.client('dynamodb')
rekognition = boto3.client('rekognition')

def get_next_product_id():
    response = dynamodb.update_item(
        TableName='ProductIDTable',
        Key={'ID': {'S': 'product_id'}},
        UpdateExpression='ADD CurrentID :increment',
        ExpressionAttributeValues={':increment': {'N': '1'}},
        ReturnValues='UPDATED_NEW'
    )
    return int(response['Attributes']['CurrentID']['N'])

def process_file(bucket_name, object_key, destination_bucket, product_id_str):
    try:
        file_extension = os.path.splitext(object_key)[1].lower()
        mime_type, _ = mimetypes.guess_type(object_key)
        file_type = mime_type or 'application/octet-stream'

        new_object_key = f'{product_id_str}/{file_type.split("/")[0]}{file_extension}'

        copy_source = {'Bucket': bucket_name, 'Key': object_key}
        s3.copy_object(CopySource=copy_source, Bucket=destination_bucket, Key=new_object_key)
        s3.delete_object(Bucket=bucket_name, Key=object_key)

        return new_object_key
    except Exception as e:
        print(e)
        return None

def get_application_token():
    with open('config.json') as f:
        config = json.load(f)
    
    client_id = config['client_id']
    client_secret = config['client_secret']
    refresh_token = config['refresh_token']
    scopes = config['scopes']

    auth = (client_id, client_secret)
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded'
    }
    data = {
        'grant_type': 'refresh_token',
        'refresh_token': refresh_token,
        'scope': scopes
    }

    response = requests.post('https://api.ebay.com/identity/v1/oauth2/token', auth=auth, headers=headers, data=data)

    if response.status_code == 200:
        token_info = response.json()
        return token_info['access_token']
    else:
        raise Exception(f'Failed to refresh token: {response.content}')

def extract_sku_from_metadata(bucket, key):
    response = rekognition.detect_text(Image={'S3Object': {'Bucket': bucket, 'Name': key}})
    for text in response['TextDetections']:
        if 'SKU' in text['DetectedText']:
            return text['DetectedText'].split('SKU:')[-1].strip()
    return None

def generate_product_listing_with_gpt(metadata):
    # Placeholder for OpenAI API call
    # Assume you have an API function `get_product_listing(metadata)`
    response = get_product_listing(metadata)
    return response

def create_ebay_listing(product_details, access_token):
    headers = {
        'Authorization': f'Bearer {access_token}',
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    }

    response = requests.post('https://api.ebay.com/sell/inventory/v1/inventory_item', headers=headers, json=product_details)

    if response.status_code in [200, 201]:
        return response.json()
    else:
        raise Exception(f'Failed to create eBay listing: {response.content}')

def repair_and_reprocess_file(bucket, key):
    # Placeholder function for repair logic
    # Implement repair logic here, such as reprocessing images, regenerating metadata, etc.
    pass

def lambda_handler(event, context):
    source_bucket = event['Records'][0]['s3']['bucket']['name']
    object_key = unquote_plus(event['Records'][0]['s3']['object']['key'])
    destination_bucket = 'processed-bucket'

    with open('config.json') as f:
        config = json.load(f)

    try:
        if config['repair_folder'] in object_key:
            repair_and_reprocess_file(source_bucket, object_key)
        else:
            product_id = get_next_product_id()
            product_id_str = f'product_{product_id:03d}'

            if object_key.endswith('/'):
                response = s3.list_objects_v2(Bucket=source_bucket, Prefix=object_key)
                if 'Contents' in response:
                    for obj in response['Contents']:
                        process_file(source_bucket, obj['Key'], destination_bucket, product_id_str)
            else:
                process_file(source_bucket, object_key, destination_bucket, product_id_str)

            skus = []
            response = s3.list_objects_v2(Bucket=destination_bucket, Prefix=product_id_str)
            if 'Contents' in response:
                for obj in response['Contents']:
                    sku = extract_sku_from_metadata(destination_bucket, obj['Key'])
                    if sku:
                        skus.append(sku)

            product_metadata = {
                'product_id': product_id_str,
                'skus': skus
            }

            product_details = generate_product_listing_with_gpt(product_metadata)
            access_token = get_application_token()
            ebay_response = create_ebay_listing(product_details, access_token)

        return {
            'statusCode': 200,
            'body': 'Successfully processed request.'
        }
    except Exception as e:
        print(e)
        return {
            'statusCode': 500,
            'body': f'Error occurred: {e}'
        }
