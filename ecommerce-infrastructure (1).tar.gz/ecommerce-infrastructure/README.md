       Ecommerce Infrastructure

This project contains the infrastructure setup for an e-commerce platform using AWS services. It includes:

- S3 Buckets for source, processed, and complete data
- Lambda functions for processing images and videos
- API Gateway for handling API requests
- DynamoDB tables for storing product information
- Cognito for user authentication
- Amplify for hosting the e-commerce stores
- EC2 instances for web hosting and proxy

## Directory Structure

```plaintext
ecommerce-infrastructure/
│
├── src/
│   ├── ImageProcessor/
│   │   └── lambda_function.py
│   ├── VideoProcessor/
│   │   └── lambda_function.py
│   ├── ListingGenerator/
│   │   └── lambda_function.py
│   ├── EbayUploader/
│   │   └── lambda_function.py
│   └── layer/
│       └── requirements.txt
│
├── templates/
│   └── ecommerce-infrastructure-template.json
│
└── README.md